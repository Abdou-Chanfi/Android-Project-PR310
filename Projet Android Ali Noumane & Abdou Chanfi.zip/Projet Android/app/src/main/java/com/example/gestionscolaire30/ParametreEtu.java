package com.example.gestionscolaire30;

import java.util.ArrayList;
import java.util.HashMap;

public class ParametreEtu {
    public static ArrayList<HashMap<String,String>> values = new ArrayList<HashMap<String,String>>();
}
