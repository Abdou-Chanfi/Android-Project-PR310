package com.example.gestionscolaire30;

import java.util.ArrayList;
import java.util.HashMap;

public class ParametrePro {
    public static ArrayList<HashMap<String,String>> valuesPro = new ArrayList<HashMap<String,String>>();
}
