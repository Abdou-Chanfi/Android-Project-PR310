package com.example.gestionscolaire30;

import java.util.ArrayList;
import java.util.HashMap;

public class ParametreMod {
    public static ArrayList<HashMap<String,String>> valuesMod = new ArrayList<HashMap<String,String>>();
}
